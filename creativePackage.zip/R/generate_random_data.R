#' Generate Random Data and Perform Summary
#'
#' This function generates a random dataset with specified dimensions and returns basic summary statistics.
#' 
#' @param n Number of rows in the dataset (default: 10).
#' @param p Number of columns in the dataset (default: 3).
#' @return A list containing the dataset and summary statistics.
#' @examples
#' result <- generate_random_data(10, 3)
#' print(result$summary)
generate_random_data <- function(n = 10, p = 3) {
  set.seed(123)
  data <- as.data.frame(matrix(runif(n * p, 0, 100), nrow = n, ncol = p))
  colnames(data) <- paste0("Var", 1:p)
  summary_stats <- summary(data)
  list(data = data, summary = summary_stats)
}
