library(testthat)
library(creativePackage)

test_that("generate_random_data works correctly", {
  result <- generate_random_data(10, 3)
  expect_equal(ncol(result$data), 3)
  expect_equal(nrow(result$data), 10)
  expect_true("summary" %in% names(result))
})
